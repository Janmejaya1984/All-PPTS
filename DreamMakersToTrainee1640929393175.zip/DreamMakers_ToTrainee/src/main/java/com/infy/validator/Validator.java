package com.infy.validator;

import com.infy.dto.MovieDTO;
import com.infy.exception.DreamMakersException;

public class Validator {

	public static void validate(MovieDTO movieDTO) throws DreamMakersException {
		
	}

	public static Boolean validateMovie(MovieDTO movieDTO) {
		return null;
	}
}
