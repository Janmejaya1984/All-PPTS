package com.infy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.infy.dto.MovieDTO;
import com.infy.exception.DreamMakersException;
import com.infy.repository.MovieRepository;

@Service(value = "movieService")
public class MovieServiceImpl implements MovieService {

	private MovieRepository movieRepository;

	public String addMovie(MovieDTO movieDTO) throws DreamMakersException {
		return null;
	}

	public List<MovieDTO> getMovies(String directorName) throws DreamMakersException {
		return null;	
	}
}
