package com.infy;

import com.infy.repository.EmployeeRepository;
import com.infy.service.EmployeeServiceImpl;

public class IManufacturerToTraineeApplicationTests {

	private EmployeeRepository employeeRepository;

	private EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();

	public void addEmployeeInvalidEmailId() throws Exception {
	}

	public void getEmployeeInvalidEmployeeId() throws Exception {
	}

	public void updateEmployeeInvalidEmployeeId() throws Exception {
	}

	public void deleteEmployeeInvalidEmployeeId() throws Exception {
	}

}
