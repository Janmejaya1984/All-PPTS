package com.infy.entity;

public class Employee {
	
}
