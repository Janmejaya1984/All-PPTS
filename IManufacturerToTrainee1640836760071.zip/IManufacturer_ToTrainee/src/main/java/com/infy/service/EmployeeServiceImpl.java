package com.infy.service;

import com.infy.dto.EmployeeDTO;
import com.infy.exception.InfyEmployeeException;


public class EmployeeServiceImpl implements EmployeeService {
	

	@Override
	public Integer addEmployee(EmployeeDTO employee) throws InfyEmployeeException {
		return null;
	}
	
	@Override
	public EmployeeDTO getEmployeeDetails(Integer employeeId) throws InfyEmployeeException {
		return null;
	}
	
	@Override
	public void updateEmployee(Integer employeeId, String emailId) throws InfyEmployeeException {
		

	}
	
	@Override
	public void deleteEmployee(Integer employeeId) throws InfyEmployeeException {

	}
}
