package com.infy.repository;

import com.infy.dto.EmployeeDTO;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	@Override
	public Integer addEmployee(EmployeeDTO employee) {
		return null;
	}

	@Override
	public EmployeeDTO getEmployeeDetails(Integer employeeId) {
		return null;
	}

	@Override
	public void updateEmployee(Integer employeeId, String emailId) {
		
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		
	}
	
	
}