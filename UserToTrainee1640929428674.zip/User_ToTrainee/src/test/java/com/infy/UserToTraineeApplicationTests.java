package com.infy;

import com.infy.exception.UsersException;
import com.infy.repository.UserRepository;
import com.infy.service.UserService;
import com.infy.service.UserServiceImpl;

class UserToTraineeApplicationTests {
	
	UserRepository userRepository;
	
	UserService userService=new UserServiceImpl();
	
	void addUserValidTest() throws UsersException {
	
	}

	void addUserInvalidUserNameTest() throws UsersException {
	
	}

	void addUserInvalidPasswordTest() throws UsersException {

	}

	void addUserInvalidEmailTest() throws UsersException {

	}

	void addUserInvalidMobileNumberTest() throws UsersException {
		
	}

	void addUserInvalidAddressTest() throws UsersException {
	
	}

}