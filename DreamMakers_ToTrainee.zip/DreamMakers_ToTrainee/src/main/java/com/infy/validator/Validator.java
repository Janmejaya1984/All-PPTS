package com.infy.validator;

import com.infy.dto.MovieDTO;
import com.infy.exception.DreamMakersException;

public class Validator {

	public static void validate(MovieDTO movieDTO) throws DreamMakersException {
		if(null==movieDTO.getMovieName()){
			throw  new  DreamMakersException("Validator.INVALID_NAMES");
		}else if(movieDTO.getMovieName().trim().length()<1){
			throw  new  DreamMakersException("Validator.INVALID_NAMES");
		}
	}

	public static Boolean validateMovie(MovieDTO movieDTO) {
		return (movieDTO.getMovieName()!=null&&movieDTO.getMovieName().trim().length()>0)?true:false;
	}
}
