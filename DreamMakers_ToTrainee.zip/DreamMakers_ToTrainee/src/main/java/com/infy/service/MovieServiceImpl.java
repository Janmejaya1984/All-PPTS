package com.infy.service;

import java.util.List;

import com.infy.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.MovieDTO;
import com.infy.exception.DreamMakersException;
import com.infy.repository.MovieRepository;

@Service(value = "movieService")
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository movieRepository;

	public String addMovie(MovieDTO movieDTO) throws DreamMakersException {
		if(Validator.validateMovie(movieDTO)){
			return movieRepository.addMovie(movieDTO);
		}else{
			throw new DreamMakersException("Service.MOVIE_NOT_FOUND");
		}

	}

	public List<MovieDTO> getMovies(String directorName) throws DreamMakersException {
		return null;	
	}
}
