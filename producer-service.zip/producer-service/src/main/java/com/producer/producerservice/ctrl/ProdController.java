package com.producer.producerservice.ctrl;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ProdController {
    @GetMapping("/produces")
    public List<String> getProducts(){
        ArrayList<String> newList = new ArrayList<>();
        newList.add("product-1");
        newList.add("product-2");
        newList.add("product-3");
        newList.add("product-4");
        newList.add("product-5");

        return newList;
    }
}
