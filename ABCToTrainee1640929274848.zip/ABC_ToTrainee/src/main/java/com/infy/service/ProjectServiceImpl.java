package com.infy.service;
import java.util.List;

import com.infy.dto.ProjectDTO;
import com.infy.exception.AbcException;


public class ProjectServiceImpl implements ProjectService {

	
	@Override
	public Integer addProject(ProjectDTO project) throws AbcException {
		
		return null;
	}


	
	@Override
	public List<ProjectDTO> getProjectDetails(String technology) throws AbcException {
		
		return null;
	}


	
}
