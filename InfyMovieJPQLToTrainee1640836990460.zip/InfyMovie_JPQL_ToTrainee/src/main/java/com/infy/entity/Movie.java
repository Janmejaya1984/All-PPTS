package com.infy.entity;

public class Movie {

}
