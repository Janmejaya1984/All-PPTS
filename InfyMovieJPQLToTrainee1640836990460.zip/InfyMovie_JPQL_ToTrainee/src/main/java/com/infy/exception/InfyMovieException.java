package com.infy.exception;

public class InfyMovieException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfyMovieException(String message) {
		super(message);
	}
}
