package com.infy.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.infy.dto.MovieDTO;

public class MovieRepositoryImpl implements MovieRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public MovieDTO getMovieByName(String movieName) {
		return null;
	}

	@Override
	public List<MovieDTO> getMoviesByImdbRating(Double fromRating, Double toRating) {
		return null;
	}

	@Override
	public List<Object[]> getMoviesNameAndYear(String directorName) {
		return null;
	}



}
