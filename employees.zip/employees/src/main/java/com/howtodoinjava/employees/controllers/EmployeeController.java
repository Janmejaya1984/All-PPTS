package com.howtodoinjava.employees.controllers;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.howtodoinjava.employees.model.Employee;
import com.howtodoinjava.employees.services.EmployeeService;

import java.util.List;

@RestController
public class EmployeeController {

  @Autowired
  EmployeeService employeeService;

  @PostMapping("/employee")
  ResponseEntity<Employee> create(@RequestBody Employee employee)  {
    Employee emp = employeeService.save(employee);
    return new ResponseEntity<>(emp,HttpStatus.CREATED);
  }

  @GetMapping("/employee")
  ResponseEntity<Iterable<Employee>> read() {
    List<Employee> employees = (List)employeeService.findAll();
    if(employees.size()>0) {
      return new ResponseEntity<>(employees,HttpStatus.OK );
    }else{
      return new ResponseEntity<>(employees,HttpStatus.NO_CONTENT);
    }
  }

  @PutMapping("/employee")
  Employee update(@RequestBody Employee employee) {
    return employeeService.save(employee);
  }

  @DeleteMapping("/employee/{id}")
  void delete(@PathVariable Integer id) {

	  employeeService.deleteById(id);
  }

  @GetMapping("/wrong")
  Employee somethingIsWrong() {
    throw new ValidationException("Something is wrong");
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(ValidationException.class)
  String exceptionHandler(ValidationException e) {
    return e.getMessage();
  }
}
