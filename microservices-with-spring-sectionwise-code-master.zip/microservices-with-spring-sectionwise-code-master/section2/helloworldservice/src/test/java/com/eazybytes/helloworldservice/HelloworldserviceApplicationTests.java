package com.eazybytes.helloworldservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldserviceApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
