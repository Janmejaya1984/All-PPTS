package com.eazybytes.helloworldservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloworldserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloworldserviceApplication.class, args);
	}

}
